Danish Traders Gujrat - Android Studio project (Java). Replace YOUR_GOOGLE_MAPS_API_KEY in AndroidManifest.xml.
